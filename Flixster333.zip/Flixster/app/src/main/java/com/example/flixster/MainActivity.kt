package com.example.flixster

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.codepath.asynchttpclient.AsyncHttpClient
import com.codepath.asynchttpclient.callback.JsonHttpResponseHandler
import okhttp3.Headers

class MainActivity : AppCompatActivity() {

    private val movies = mutableListOf<Movie>()
    private lateinit var moviesAdapter: MoviesAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 1) Set up RecyclerView
        val rvMovies = findViewById<RecyclerView>(R.id.rvMovies)
        moviesAdapter = MoviesAdapter(movies)
        rvMovies.adapter = moviesAdapter
        rvMovies.layoutManager = LinearLayoutManager(this)

        // 2) API Request
        val client = AsyncHttpClient()
        val NOW_PLAYING_URL =
            "https://api.themoviedb.org/3/movie/now_playing?api_key=a07e22bc18f5cb106bfe4cc1f83adbed"

        client.get(NOW_PLAYING_URL, object : JsonHttpResponseHandler() {
            override fun onSuccess(
                statusCode: Int,
                headers: Headers?,
                json: JSON?
            ) {
                Log.d("Flixster", "Response successful")
                Log.d("Flixster", json?.jsonObject.toString())

                // 3) Parse JSON
                val results = json?.jsonObject?.getJSONArray("results")

                if (results != null) {
                    for (i in 0 until results.length()) {
                        val movieJson = results.getJSONObject(i)

                        val movie = Movie(
                            title = movieJson.getString("title"),
                            overview = movieJson.getString("overview"),
                            posterPath = movieJson.getString("poster_path")
                        )

                        movies.add(movie)
                    }

                    // 4) Update the RecyclerView
                    moviesAdapter.notifyDataSetChanged()
                }
            }

            override fun onFailure(
                statusCode: Int,
                headers: Headers?,
                response: String?,
                throwable: Throwable?
            ) {
                Log.e("Flixster", "Request failed", throwable)
            }
        })
    }
}
