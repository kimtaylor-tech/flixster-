package com.example.flixster

data class Movie(
    val title: String,
    val overview: String,
    val posterPath: String
) {
    val posterImageUrl: String
        get() = "https://image.tmdb.org/t/p/w500$posterPath"
}
